package frontend;

interface Node {
    public Node getParentNode();   
}
