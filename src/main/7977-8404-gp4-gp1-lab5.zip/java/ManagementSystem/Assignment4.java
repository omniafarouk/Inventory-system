package ManagementSystem;

import frontend.InventorySystem;

public class Assignment4 {

    public static void main(String[] args) {
       InventorySystem system = new InventorySystem();
       system.setVisible(true);

    }
}
