package backend;

interface Account {
    String lineRepresentation();
    String getSearchKey();
}
