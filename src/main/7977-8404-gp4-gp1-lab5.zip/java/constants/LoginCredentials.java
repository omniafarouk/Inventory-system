package constants;

public interface LoginCredentials {
    String ADMIN_USERNAME = "admin";
    String ADMIN_PASSWORD = "12345";
    String EMPLOYEE_USERNAME = "librarian";
    String EMPLOYEE_PASSWORD = "56789";
}
