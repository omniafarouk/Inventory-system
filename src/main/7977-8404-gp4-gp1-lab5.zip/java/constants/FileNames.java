package constants;

public interface FileNames {
    String PRODUCT_FILENAME = "Products.txt";
    String EMPLOYEE_FILENAME = "Employees.txt";
    String CUSTOMERPRODUCT_FILENAME = "CustomerProducts.txt";
}
